# Foreign Medical & Health Scholarship Portal — MVP

A narrow, deliberately small Streamlit app for Indian students weighing
foreign medical/health education: scholarships explicitly open to
medicine, public health, or nursing, cross-referenced against real
FMGE/NExT return-to-India outcomes by country.

## Why this is narrow on purpose

The earlier general "all foreign scholarships" version competed head-on
with established, better-resourced aggregators (scholars4dev, IEFA,
Buddy4Study) and its headline feature — acceptance rates — was only
populated for a handful of famous scholarships. This version drops
that fight entirely and focuses on the one thing no generic scholarship
site offers: **linking a funding decision to the licensing reality**
Indian medical graduates face after they come home.

## Setup

```bash
pip install -r requirements.txt
streamlit run app.py
```

## What's inside

- **Tab 1 — Scholarships**: 12 curated scholarships explicitly checked
  for eligibility in medicine/public health/nursing (several popular
  scholarships, like Inlaks, explicitly *exclude* medicine — those are
  left out rather than listed misleadingly). Each row has a source URL,
  grade requirement, funding type, and a "last verified" date.
- **Tab 2 — Country FMGE/NExT outcomes**: approximate pass-rate ranges
  by source country, aggregated from third-party education-consultancy
  reporting on NBE results. Explicitly labeled as directional, not
  authoritative — always cross-check the live number at
  [natboard.edu.in](https://natboard.edu.in) before deciding.
- A standing banner explaining the actual regulation: **every** Indian
  citizen/OCI pursuing a foreign medical degree needs an NMC Eligibility
  Certificate before enrolling and must clear FMGE/NExT after returning,
  regardless of country — there's no such thing as a blanket "NMC
  recognized country," so the app never claims one.

## No live scraping in this version

Unlike the earlier general-purpose build, this one is 100% curated CSVs
(`data/scholarships.csv`, `data/country_fmge_outcomes.csv`) with
per-row source URLs and verification dates. For content this
consequential (a multi-year, multi-lakh-rupee education decision),
a small, dated, sourced dataset is more trustworthy than a large
scraped one with unclear provenance.

## Keeping it current

- Re-verify each scholarship row against its `url` roughly every
  6 months (deadlines and eligibility criteria shift) and bump
  `last_verified`.
- Update `country_fmge_outcomes.csv` after each FMGE/NExT result
  (June and December sessions) using NBE's published session report
  as the primary source where possible, keeping the aggregator figures
  only as a cross-check.

## Deploying

Same as the general version — see the original README's deployment
section, or quickest path:
```bash
git init && git add . && git commit -m "Medical scholarship portal MVP"
# push to GitHub, then deploy free at https://share.streamlit.io
```

## Files

```
app.py                          Streamlit app (2 tabs)
data_store.py                    CSV loading (no scraping)
data/scholarships.csv             12 curated, health-eligible scholarships
data/country_fmge_outcomes.csv     Country-wise approx. FMGE/NExT pass rates
requirements.txt                 Dependencies
```
